/// @ref core
/// @file glm/vec4.hpp

#pragma once

#include "detail/type_vec4.hpp"
